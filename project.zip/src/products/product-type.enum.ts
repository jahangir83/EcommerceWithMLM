export enum ProductType {
  PHYSICAL = 'physical',
  DIGITAL = 'digital',
}
