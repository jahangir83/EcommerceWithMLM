import { IsEmail, IsString, MinLength, IsPhoneNumber, IsOptional } from "class-validator"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger"

export class RegisterDto {
  @ApiProperty({
    description: "User email address",
    example: "user@example.com",
    format: "email",
  })

  @IsString()
  username:string

  @IsEmail()
  email: string

  @ApiProperty({
    description: "User password",
    example: "password123",
    minLength: 6,
  })
  @IsString()
  @MinLength(6)
  password: string

  @ApiProperty({
    description: "User phone number",
    example: "+8801631551301",
  })
  @IsPhoneNumber()
  phone: string

  @ApiProperty({
    description: "User first name",
    example: "John",
  })

  @IsOptional()
  @IsString()
  firstName: string

  @ApiProperty({
    description: "User last name",
    example: "Doe",
  })
  @IsOptional()
  @IsString()
  lastName: string

  @IsOptional()
  @IsString()
  avater:string

  @ApiPropertyOptional({
    description: "Referral code from existing user",
    example: "REF123456",
  })
  @IsOptional()
  @IsString()
  referralCode?: string
}


