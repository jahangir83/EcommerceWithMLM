export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER',
  VENDOR = 'VENDOR',
  DEVELOPER = 'DEVELOPER',
}
